#ifndef REMPLISSAGE_H
#define REMPLISSAGE_H

enum Filling {
	plein,
	vide
};
	
#endif
